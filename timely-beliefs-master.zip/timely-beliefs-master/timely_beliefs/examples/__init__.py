from timely_beliefs.examples.beliefs_data_frames import sixteen_probabilistic_beliefs


example_df = sixteen_probabilistic_beliefs()
